appActivate("com.haegin.playtogether");
while 1 do
 usleep(1000000)
 tap(1762, 747); --nhan vao nut cau
 usleep(3000000)
 if (getColor(2092, 664)~=14893121) then --kiem tra xem co tui do ko
 repeat
 usleep(1)
 until (getColor(1104, 123)==16777215) or (getColor(1110, 34)==16777215)
 touchDown(2, 1909, 969);
 usleep(16000);
 touchUp(2, 1909, 969);
 while 1 do 
 if (getColor(1478, 437)==16777215) then --kiem tra xem co bang thong bao khong
 touchDown(3, 1731,1013);
 usleep(51291.04);
 touchUp(3, 1731,1013);
 break
 elseif (getColor(2092,664)==14893121) then --kiem tra xem co tui do ko
 break
 end
 end
 else --neu co bieu tuong tui do => day cau bi dut
 tap(2092, 664); --nhan vao tui do
 usleep(1000000);
 tap(1590, 94); --nhan vao muc can cau
 usleep(600000);
 tap(1642, 583); --chon sua
 usleep(600000);
 tap(1214, 946); --nhan tien
       usleep(1000000);
 tap(1214, 946); --ok
       usleep(600000);
       tap(2135, 90); --nhan thoat
 usleep(1500000);
 end
end