appActivate("com.haegin.playtogether");
while 1 do
	usleep(1000000)
	tap(1956.65, 647.47); --nhan vao nut cau
	usleep(3000000)
	if (getColor(2270, 578)~=14893121) then --kiem tra xem co tui do ko
		repeat
			usleep(1)
		until (getColor(1223, 155)==16777215) or (getColor(1222, 46)==16777215)
		touchDown(3, 2131.72, 853.91);
		usleep(16000);
		touchUp(3, 2131.72, 853.91);
		while 1 do 
			if (getColor(1720, 573)==16777215) then --kiem tra xem co bang thong bao khong
				touchDown(1, 1827.74, 900.96);
				usleep(51291.04);
				touchUp(1, 1827.74, 900.96);
				break
			elseif (getColor(2270, 578)==14893121) then --kiem tra xem co tui do ko
				break
			end
		end
	else --neu co bieu tuong tui do => day cau bi dut
		tap(2249.07, 617.71); --nhan vao tui do
		usleep(1000000);
		tap(1819.08, 93.45); --nhan vao muc can cau
		usleep(800000);
		tap(1545, 526); --chon sua
		usleep(800000);
		tap(1228, 881); --nhan tien
		usleep(1500000);
		repeat --cho bang thanh cong xuat hien, tranh truong hop mang lag
			color=getColor(1215, 934)
		until color==16777215
		tap(1218, 879); --nhan ok
		usleep(1000000);
		tap(1563.20, 468.89); --nhan thoat
	end
end