
local app = ""
local chay = true
--play together

----------xac dinh vi tri
local xf = 0
local yf = 0
local cf = 16711678 --trang
local xstart = 0
local xend = 0
local ystart = 0
local yend = 0
local chayx = true
local chayy = true

----------cau ca
local r = 0
local c = 0
--1242x2208
--alert(r..c)
local checkp = 0
local checkcl = 0
local dinh = 16777215
local duoi = 16700000
local tren = 16799999
--alert(getColor(checkp, 10))
local catca = 16777215
local cauca = false
local timeCau = 0

----------su kien
local evt = ""
local fram = ""

----------sua can cau
local suacancau = false
local clkimcuong = 0
local clvang = 0

while true do

if r==0 then
 r,c = getScreenResolution()
 checkp = r/2
end

if chay and r~=0 then -- co dinh vi va check hay k

if cauca==false and suacancau==false then --dinh vi truoc khi cau

 local cten = findColor(65280, 0, {700, 10, 1500, 500}); 
 -- 0x00FF00, (1075,637) --xanh

 if #cten>0 then

 xstart = cten[1][1]
 xend = cten[#cten][1]

 for i=1, #cten, 1 do

 local xtemp = cten[i][1]

 if xstart > xtemp then
 xstart = xtemp
 end

 if xend < xtemp then
 xend = xtemp
 end
 end --for

 xf = xstart + (xend - xstart)/2
 yf = cten[1][2]

 end --if

 local xm = r/2
 local ym = (xend - xstart)*1.5

 if xf<xm-7  then
 touchDown(1,xf ,500 );
 usleep(10000)
 touchMove(1,xf+3 ,500 );
 usleep(10000)
 touchUp(1,xf+3 ,500 );
 elseif xf>xm+7  then
 touchDown(1,xf ,500 );
 usleep(10000)
 touchMove(1,xf-3 ,500 );
 usleep(10000)
 touchUp(1,xf-3 ,500 ); 
 else
 chayx = false
 if yf<ym  then
 touchDown(1,1000 ,yf );
 usleep(10000)
 touchMove(1,1000 ,yf+5 );
 usleep(10000)
 touchUp(1,1000 ,yf+5 );
 else
 chayy = false
 cauca = true
 end
 end
end --if dinh vi xong

if cauca then --bat dau cau ca
 checkcl = getColor(checkp, 10);
 local cctemp = getColor(2056, 559);

--alert(cctemp)
 if catca==cctemp then
 local cctemp1 = getColor(1827.74, 900.96);
 if catca==cctemp1 then
 --tap(1538, 1008);
 --tap(1631, 968);
 usleep(200000);
 tap(1827.74, 900.96);--bao quan
 usleep(700000);
 tap(1956.65, 647.47);--cau ca
 usleep(1500000)
 local clkimcuongtmp = getColor(1656, 62);
 if clkimcuong==clkimcuongtmp then
 local clvangtmp = getColor(1934, 56);
 if clvang==clvangtmp then
 suacancau = true
 
 end
 end
 cctemp1 = 0;
 cctemp = 0;
 end
 else
 if checkcl==dinh then --ca can cau
 tap(2131.72, 853.91);
 checkcl = 0
 usleep(500000)
 --alert(checkcl)
 end
 end
end --if cau ca

end--if cho phep chay

app = appState("com.haegin.playtogether")
if app=="ACTIVATED" then
chay = true
usleep(100000) end
if app=="DEACTIVATED" or app=="NOT RUNNING" then
chay = false
usleep(2000000) end

end --while

function checkfram()

 return
end

--HOME
--CAUCA
--CAUCA_BAOQUAN
--