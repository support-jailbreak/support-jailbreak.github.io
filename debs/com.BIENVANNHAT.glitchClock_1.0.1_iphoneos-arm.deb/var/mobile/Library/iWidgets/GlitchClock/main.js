/* Copyright © 0neguy Inc. 2019 */

var $ = document;

var time = document.getElementById("clock")
var date = document.getElementById("date")

var dayText;
var monthText;
var finalMin;
var finalHour;

function prefs() {
    time.style.color = clockColor;
    date.style.color = dateColor;
    if (dateShow === 0) {
        date.style.display = "none";
    }
    if (clockShow === 0) {
        time.style.display = "none";
    }
}

function updateTime() {
    let d = new Date();
    let dayStr = d.getDay();
    let monthStr = d.getMonth();

    if (dayStr === 1) {
        dayText = "Thứ 2 "
    } else if (dayStr === 2) {
        dayText = "Thứ 3 ";
    } else if (dayStr === 3) {
        dayText = "Thứ 4 ";
    } else if (dayStr === 4) {
        dayText = "Thứ 5 ";
    } else if (dayStr === 5) {
        dayText = "Thứ 6 ";
    } else if (dayStr === 6) {
        dayText = "Thứ 7 ";
    } else if (dayStr === 0) {
        dayText = "Chủ nhật ";
    };


    if (monthStr === 0) {
        monthText = "Tháng một";
    } else if (monthStr === 1) {
        monthText = "Tháng hai";
    } else if (monthStr === 2) {
        monthText = "Tháng ba";
    } else if (monthStr === 3) {
        monthText = "Thánh tư";
    } else if (monthStr === 4) {
        monthText = "Tháng năm";
    } else if (monthStr === 5) {
        monthText = "Tháng 6";
    } else if (monthStr === 6) {
        monthText = "Tháng 7";
    } else if (monthStr === 7) {
        monthText = "Tháng 8";
    } else if (monthStr === 8) {
        monthText = "Tháng 9";
    } else if (monthStr === 9) {
        monthText = "Tháng 10";
    } else if (monthStr === 10) {
        monthText = "Tháng 11";
    } else if (monthStr === 11) {
        monthText = "Tháng 12";
    };

    if (d.getMinutes() < 10) {
        finalMin = "0" + d.getMinutes()
    } else {
        finalMin = d.getMinutes()
    }

    let finalHour = d.getHours();

    if (twelvehr === 1) {
        if (d.getHours() > 12) {
            finalHour -= 12;
        } else if (d.getHours() === 0) {
            finalHour = 12;
        }
    }

    setTimeout(function () {
        if (addZeros === 1) {
            if (finalHour < 10) {
                finalHour = "0" + finalHour;
            }
        }
        time.innerHTML = finalHour + "" + finalMin;
        date.innerHTML = dayText + "// " + d.getDate() + " // " + monthText;
    }, 800)
}

setInterval(function () {
    updateTime();
}, 1000)

document.body.onload = function () {
    updateTime();
    prefs();
    $.body.style.opacity = "1.0";
    $.body.style.transform = "scale(" + widgetSize + ")";
}